# Icons

Put your application icon and any small button icons here.

Example filenames: `app.ico` for a Windows application icon and `save.png` for a Save button.

Add the actual files before referencing them in your code or build command. This folder currently contains this guide only.
