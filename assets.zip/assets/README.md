# Assets

This folder holds the images and icons used by your application.

| Folder | What belongs here | Example filenames |
| --- | --- | --- |
| `images/` | Logos, backgrounds, and other pictures shown in the window. | `logo.png`, `background.png` |
| `icons/` | The application icon and small button icons. | `app.ico`, `save.png` |

The filenames above are examples; this starter contains guides, not image files. Add your own pictures and icons when you need them.

Keep `assets/` beside `run.py`. For example, a logo would be stored at `assets/images/logo.png`.

Your Python code must load each asset before it appears in the window. If you package the app as an executable, include the assets it uses in that build.

Commit the image and icon files you intend to distribute with your application to Git.
