# Images

Put your application's logos, background pictures, and other screen images here.

Example filenames: `logo.png`, `background.png`, and `welcome.png`.

Add your own image files; these examples are names only. Use simple filenames so they are easy to reference from your Python code.
